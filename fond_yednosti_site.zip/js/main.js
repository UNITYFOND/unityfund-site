// Простий JS для мобільного меню
document.addEventListener('DOMContentLoaded', function(){
  const burger = document.getElementById('burger');
  const nav = document.querySelector('.nav');
  burger && burger.addEventListener('click', function(){
    if(nav.style.display === 'block') nav.style.display = '';
    else nav.style.display = 'block';
  });
});
